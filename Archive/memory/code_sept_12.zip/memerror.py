class NOMEMORY(Exception):
    pass