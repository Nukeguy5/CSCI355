
class MemCommon:
    row_size = 7

class Invalid(Exception):
    pass

class NoMemory(Exception):
    pass